package com.example.pharmascan.ui.theme

import androidx.compose.ui.graphics.Color

val Orange80 = Color(0xFFFF5722)
val OrangeGrey80 = Color(0xFFF57C00)
val LightOrange80 = Color(0xFFFF9100)

val Orange40 = Color(0xFFFF9100)
val OrangeGrey40 = Color(0xFFFF8F00)
val LightOrange40 = Color(0xFFFFE0B2)